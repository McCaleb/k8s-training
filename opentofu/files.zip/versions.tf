terraform {
  required_version = ">= 1.6"

  required_providers {
    proxmox = {
      source = "bpg/proxmox"
      # bpg/proxmox is pre-1.0 and does not guarantee backward compatibility
      # between minor versions, so pin to a patch range rather than a minor one.
      version = "~> 0.111.0"
    }
  }
}

provider "proxmox" {
  endpoint  = var.pve_endpoint
  api_token = var.pve_api_token
  insecure  = var.pve_insecure
}
