resource "proxmox_virtual_environment_vm" "worker" {
  for_each = var.workers

  name        = each.key
  vm_id       = each.value.vm_id
  node_name   = each.value.node
  description = "Kubernetes worker, managed by OpenTofu"
  tags        = ["k8s", "worker"]

  on_boot = true
  started = true

  # Change the node in var.workers and the VM is migrated rather than rebuilt.
  migrate = true

  clone {
    vm_id     = var.template_vm_id
    node_name = var.template_node
    full      = true

    # Forces the post-clone migration step to place disks on this datastore,
    # which matters when the target node differs from var.template_node.
    datastore_id = var.datastore_id

    # Six full clones from one source can trip the Proxmox clone timeout.
    retries = 3
  }

  # The template must have qemu-guest-agent installed AND enabled, or every
  # create, refresh and destroy blocks until agent.timeout expires.
  # Set enabled = false (and add stop_on_destroy = true) if it is not.
  agent {
    enabled = true
  }

  # Schema defaults override the source VM's values on a clone, so cpu.type and
  # scsi_hardware are set explicitly rather than left to default to qemu64 and
  # virtio-scsi-pci. Compare against: qm config 101
  cpu {
    cores   = var.cores
    sockets = 1
    type    = "x86-64-v2-AES"
  }

  memory {
    dedicated = var.memory
  }

  scsi_hardware = "virtio-scsi-single"

  # Same caveat as above, and it bites hardest here: because `size` is set, every
  # other disk attribute that differs from the schema default must also be set
  # explicitly or the default silently replaces the template's value.
  disk {
    datastore_id = var.datastore_id
    interface    = "scsi0"
    size         = var.disk_size
    file_format  = "raw"
    cache        = "none"
    aio          = "io_uring"
    discard      = "on"
    iothread     = true
    ssd          = false
    backup       = true
    replicate    = true
  }

  initialization {
    datastore_id = var.cloudinit_datastore_id
    interface    = "ide2"

    dns {
      servers = var.dns_servers
      domain  = var.dns_domain
    }

    ip_config {
      ipv4 {
        address = "${each.value.ip}/${var.prefix_length}"
        gateway = var.gateway
      }
    }

    user_account {
      username = var.ci_username
      keys     = var.ci_ssh_keys
    }
  }

  network_device {
    bridge = var.network_bridge
    model  = "virtio"
  }

  operating_system {
    type = "l26"
  }

  # REQUIRED, not cosmetic. Debian and Ubuntu cloud images kernel panic when the
  # boot disk is resized unless a serial device is present. Because this config
  # sets disk.size, that path is guaranteed to be taken.
  # See bpg/terraform-provider-proxmox issues #1639 and #1770.
  serial_device {
    device = "socket"
  }
}
